from flask import Flask, render_template, request
import random

app = Flask(__name__)
secret_number = random.randint(1, 10)

@app.route('/', methods=['GET', 'POST'])
def index():
    message = ''
    if request.method == 'POST':
        guess = request.form.get('guess')
        if guess:
            try:
                guess = int(guess)
                if guess == secret_number:
                    message = f'آفرین! عدد درست {secret_number} بود.'
                else:
                    message = f'اشتباهه! تلاش کن دوباره.'
            except ValueError:
                message = 'عدد معتبر وارد کن!'
    return render_template('index.html', message=message)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
